(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) {
    module.exports = api;
  }
  root.LabelNovaPlacement = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  function toPositiveNumber(value) {
    const num = Number(value);
    return Number.isFinite(num) && num > 0 ? num : 0;
  }

  function placeObjectWithinCanvas(options) {
    const canvasWidth = toPositiveNumber(options && options.canvasWidth);
    const canvasHeight = toPositiveNumber(options && options.canvasHeight);
    const objectWidth = toPositiveNumber(options && options.objectWidth);
    const objectHeight = toPositiveNumber(options && options.objectHeight);
    const maxFillRatio = Math.min(Math.max(Number(options && options.maxFillRatio) || 0.92, 0.1), 1);

    let scale = 1;
    const widthScale = objectWidth > 0 ? (canvasWidth * maxFillRatio) / objectWidth : Number.POSITIVE_INFINITY;
    const heightScale = objectHeight > 0 ? (canvasHeight * maxFillRatio) / objectHeight : Number.POSITIVE_INFINITY;
    if (canvasWidth > 0 && canvasHeight > 0 && (objectWidth > 0 || objectHeight > 0)) {
      scale = Math.min(1, widthScale, heightScale);
    }

    const fittedWidth = objectWidth * scale;
    const fittedHeight = objectHeight * scale;

    return {
      left: Math.max(0, (canvasWidth - fittedWidth) / 2),
      top: Math.max(0, (canvasHeight - fittedHeight) / 2),
      scale,
      fittedWidth,
      fittedHeight,
    };
  }

  function resolveObjectPlacement(options) {
    const scaleX = toPositiveNumber(options && options.scaleX) || 1;
    const scaleY = toPositiveNumber(options && options.scaleY) || 1;
    const objectWidth = toPositiveNumber(options && options.objectWidth);
    const objectHeight = toPositiveNumber(options && options.objectHeight);

    const placement = placeObjectWithinCanvas({
      canvasWidth: options && options.canvasWidth,
      canvasHeight: options && options.canvasHeight,
      objectWidth: objectWidth * scaleX,
      objectHeight: objectHeight * scaleY,
      maxFillRatio: options && options.maxFillRatio,
    });

    return {
      left: placement.left,
      top: placement.top,
      scale: placement.scale,
      scaleX: scaleX * placement.scale,
      scaleY: scaleY * placement.scale,
      fittedWidth: placement.fittedWidth,
      fittedHeight: placement.fittedHeight,
    };
  }

  return {
    placeObjectWithinCanvas,
    resolveObjectPlacement,
  };
});
