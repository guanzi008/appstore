(function (global) {
  function compareByName(left, right) {
    if (left.name === right.name) return 0;
    return left.name < right.name ? -1 : 1;
  }

  function normalizeLocalFonts(fonts) {
    const entries = Array.isArray(fonts) ? fonts : [];
    const fontMap = new Map();

    entries.forEach((font) => {
      if (!font || typeof font !== "object") return;

      const value = font.value || font.postscriptName || font.family || font.fullName || font.name;
      const name = font.name || font.fullName || font.family || font.value || font.postscriptName;

      if (!value || !name || fontMap.has(value)) return;
      fontMap.set(value, { name, value });
    });

    return Array.from(fontMap.values()).sort(compareByName);
  }

  function buildLocalFontsFeedback(fontCount) {
    if (fontCount > 0) {
      return {
        type: "success",
        message: `成功加载 ${fontCount} 款本地字体`,
      };
    }

    return {
      type: "info",
      message: "未发现可用的本地字体",
    };
  }

  function shouldShowCustomWindowControls(options = {}) {
    return !options.isQt;
  }

  const api = {
    normalizeLocalFonts,
    buildLocalFontsFeedback,
    shouldShowCustomWindowControls,
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }

  global.LabelNovaDesktopRuntime = api;
})(typeof window !== "undefined" ? window : globalThis);
